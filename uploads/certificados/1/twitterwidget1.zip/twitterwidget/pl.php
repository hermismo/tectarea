<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{twitterwidget}prestashop>twitterwidget_73b72cf7bea3a427ed076fadfeee8ff2'] = 'Twitter Widget za darmo';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_71857962e58f15a2a1a031b68faa5ea6'] = 'Ten moduł dodaje widget twittera do Twojego sklepu';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Potwierdzenie';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_c888438d14855d7d96a2724ee9c306bd'] = 'Ustawienia Zapisane';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_f67bc99cb81f84cf5f22f323d0051583'] = 'Ustawienia Twitter Widget Free';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_f9e4884c7654daa6581b42ed90aeaba4'] = 'Lewa kolumna';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_a6105c0a611b41b08f1209506350279e'] = 'tak';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_feb6cc332459769fe15570bf332a6b50'] = 'Prawa kolumna';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_8cf04a9734132302f96da8e113e80ce5'] = 'Strona Główna';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_a676a52506a4b5016fdd0c844e60d8d4'] = 'Szerokość widgetu';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_b9cfba5082d9cf8bcdb47427cdc68b6f'] = 'Minimalna wartość szerokości: 220';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_198fae7418302c5eb07213a463b4ce11'] = 'Twitter Login';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_6aae0f6960b2cdbe3442626175fc2d71'] = 'Nazwa Twojego konta na twitterze';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_4d2900f87d53445bad2db338bf31a6da'] = 'Twitter widget ID';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_20c92ed5f444f140c58879ba68488e30'] = 'Wprowadź numer ID Twojego widgeta';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_9daf1fb753b42c3cdc8f1d01669cd6d8'] = 'Zapisz ustawienia';
