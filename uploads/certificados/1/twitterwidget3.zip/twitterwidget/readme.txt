This module is in version 1.0

check http://mypresta.eu for newest versions!
