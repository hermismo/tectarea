<?php
$lang['required'] = "El campo <strong>%s</strong> es obligatorio.";
$lang['valid_email'] = "El campo <strong>%s</strong> debe contener una direcci&oacute;n de email v&aacute;lida.";
$lang['validaSelect'] = "Debe seleccionar alguna opción del campo <strong>%s</strong>.";
$lang['min_length']="El campo <strong>%s</strong> debe tener al menos <strong>%s</strong>";
$lang['max_length']="El campo <strong>%s</strong> debe tener como máximo <strong>%s</strong> caracteres.";
$lang['numeric']= "El campo <strong>%s</strong> debe ser numérico";

/* End of file form_validation_lang.php */
/* Location: ./system/language/spanish/form_validation_lang.php */
