<h1 class="muestra2">Acerca de nosotros</h1>
<h2><?= $somos?></h2>
<h3><?= $hacer?></h3>
<h4><?= $estar?></h4>
<img src="<?= base_url()?>public/imagenes/imagen.jpg"/>

<a href="javascript:saludo();">Click</a><br>
<a href="javascript:saludo_desde_libreria();">Click</a>