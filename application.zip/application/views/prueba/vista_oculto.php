<p><?= $saludo ?></p>
<p>El valor de id es: <?= $id ?></p>
<p>El valor del id2 es: <?= $id2 ?></p>
<p>La cadena de texto es: <?= $cadena ?></p>