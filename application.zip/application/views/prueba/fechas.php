<p><?= $saludo ?></p>
<?php
    echo $fecha_actual;
?>

<p><?= $fecha_string?></p>
<p><?= $hora_string?></p>

