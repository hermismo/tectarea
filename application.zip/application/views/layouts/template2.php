
<?php echo $content_for_layout; ?>
</body>
</html>