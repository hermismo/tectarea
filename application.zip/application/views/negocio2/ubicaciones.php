<strong><h4>Tu Disponibilidad<font color="red">(*) </font></h4> </strong><br>
<div id="tabla_ubicaciones"> 
<div class="table-responsive">
	<table class="table">
		<thead>
			<tr>
				<th></th>
				<th>Lunes</th>
				<th>Martes</th>
				<th>Miercoles</th>
				<th>Jueves</th>
				<th>Viernes</th>
				<th>Sábado</th>
				<th>Domingo</th>			
			</tr>	
		</thead>
		<tbody>
			<tr>
				<th>Mañana</th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>			
			</tr>
			<tr>
				<th>Al Mediodia</th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>			
			</tr>
			<tr>
				<th>Tardes</th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>
				<th><input type="checkbox"></th>			
			</tr>	
		</tbody>
	</table>
</div>
</div>