<div class="container">
    <h2>Error</h2>
   
    <div class="alert alert-danger">
    <h4>No tiene permiso para acceder a esta página.</h4>
    </div>
</div>