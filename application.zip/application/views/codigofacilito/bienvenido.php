<body>

<div id="container">
    <h1>Llamado desde el controlador Código facilito</h1>
    <!--
    <h2> <?= getNombre()?></h2>
    <h3><?= $mi_menu?></h3>
    -->
</div>

</body>
</html>