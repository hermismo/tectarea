<h3>Experiencia</h3>
	<div>
		<label>Tectarea valora tu experiencia en certificación energética y te premiamos por ello.</label>
		<div id="sombra"></div>

		<label>¿Cómo adjuntar los ficheros de tus certificados energéticos ?</label>
		<div id="sombra"></div>

		<label>No olvides solicitar tu valoración en Tus valoraciones</label>
		<div id="sombra"></div>

		<label>Muestra en el comparador tu experiencia, adjunta todos tus certificados no realizados en Tectarea</label>
		<div id="sombra">
		<p>Los clientes eligen a los técnicos con mas experiencia. Aporta tantos certificados como tengas para maximizar tus probabilidades.</p>

		Adjuntar fichero fuente <br>
		<input type="file" >
		</div>
	</div>