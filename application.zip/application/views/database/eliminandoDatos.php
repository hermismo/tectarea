<div class="contenedor_cabecera">
    <h1>Formulario</h1>
</div>

<div>

</div>